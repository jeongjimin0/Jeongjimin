package Swing;

public class run {

		public static void main(String[] args) {
			
			new LoginScreen();

		}

	
}
